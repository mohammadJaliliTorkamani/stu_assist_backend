# Stu Assist - Backend

Assistance for applicants

Under development
