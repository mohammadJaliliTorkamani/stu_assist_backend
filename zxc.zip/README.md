# Stu Assist - Backend

Assistance for applicants
Frontend client : [Here](https://github.com/mohammadJaliliTorkamani/stu_assist)
